a["{\"msg\":\"removed\",\"collection\":\"kadira_settings\",\"id\":\"iNHtGErmgzYuq2y3B\"}"]
