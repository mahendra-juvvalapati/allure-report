a["{\"msg\":\"removed\",\"collection\":\"kadira_settings\",\"id\":\"HZ5DoYuxxsAPMDkDv\"}"]
