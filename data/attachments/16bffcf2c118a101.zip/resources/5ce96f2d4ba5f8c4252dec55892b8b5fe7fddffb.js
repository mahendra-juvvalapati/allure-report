a["{\"msg\":\"removed\",\"collection\":\"kadira_settings\",\"id\":\"9huSxvs2dGhPKvQpm\"}"]
